# Minahasa Image Pack for Virtual Museum

This pack contains 11 web-optimized images for the Minahasa virtual museum project.

## How to use

1. Unzip this package into your project root.
2. Copy or keep the folder:

   `src/assets/images/minahasa/`

3. In `src/data/artworks.json`, reference images like this:

   `./src/assets/images/minahasa/watu-pinawetengan.jpg`

4. Keep `CREDITS-MANIFEST.csv` or `credits-manifest.json` somewhere in your project. The Creative Commons images require credit.

## Important rights note

These images were selected from Wikimedia Commons because they are marked as public domain, CC0, or Creative Commons licensed. For CC BY and CC BY-SA images, you must give attribution. For CC BY-SA images, adaptations/remixes may need to be shared under a compatible ShareAlike license.

All images in this pack were resized/compressed for web use, and that change is noted in the manifest.

## Included helper file

`minahasa-artworks-starter.json` is a draft catalog using these image paths. You can copy parts of it into `src/data/artworks.json`, but the text is only starter text and should be improved later.
